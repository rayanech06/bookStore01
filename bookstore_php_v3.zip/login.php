<?php
require_once 'includes/config.php';
$pageTitle  = 'Connexion';
$activePage = 'login';
$cssPath    = '';

$error    = '';
$redirect = $_GET['redirect'] ?? 'index.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $mdp   = trim($_POST['mot_de_passe'] ?? '');

    if ($email && $mdp) {
        $db   = getDB();
        $stmt = $db->prepare('SELECT * FROM clients WHERE email = ? AND mot_de_passe = SHA2(?,256) LIMIT 1');
        $stmt->execute([$email, $mdp]);
        $client = $stmt->fetch();

        if ($client) {
            $_SESSION['client_id']  = $client['id'];
            $_SESSION['client_nom'] = $client['prenom'] . ' ' . $client['nom'];
            $_SESSION['success']    = '👋 Bienvenue, ' . $client['prenom'] . ' ♡';
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Email ou mot de passe incorrect.';
        }
    } else {
        $error = 'Veuillez remplir tous les champs.';
    }
}

include 'includes/header.php';
?>

<div style="min-height:60vh;display:flex;align-items:center;justify-content:center;padding:40px 20px;">
  <div class="form-card">
    <div style="text-align:center;font-size:2.5rem;margin-bottom:10px;">📖</div>
    <h2 class="form-title">Connexion</h2>
    <p class="form-subtitle">Books · Dreams · Adventures ♡</p>

    <?php if ($error): ?>
      <div class="alert alert-error">⚠ <?= e($error) ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['success'])): ?>
      <div class="alert alert-success"><?= e($_SESSION['success']) ?></div>
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <form method="POST">
      <input type="hidden" name="redirect" value="<?= e($redirect) ?>">
      <div class="form-group">
        <label class="form-label">📧 Email</label>
        <input type="email" name="email" class="form-input"
               placeholder="votre@email.com" required
               value="<?= e($_POST['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">🔒 Mot de passe</label>
        <input type="password" name="mot_de_passe" class="form-input"
               placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn btn-pink" style="width:100%;justify-content:center;margin-top:8px">
        🔑 Se connecter
      </button>
    </form>

    <span class="form-link">
      Pas encore inscrit ? <a href="register.php">Créer un compte ♡</a>
    </span>
    <div style="margin-top:16px;padding:12px;background:var(--pink-pale);border-radius:10px;border:1.5px dashed var(--pink-light);">
      <p style="font-size:.75rem;color:var(--brown-light);text-align:center;font-style:italic;">
        Comptes de test :<br>
        sara@example.com / sara1234<br>
        youssef@example.com / youssef1234
      </p>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
