<?php
require_once 'includes/config.php';
$_SESSION['client_id']  = null;
$_SESSION['client_nom'] = null;
unset($_SESSION['client_id'], $_SESSION['client_nom']);
session_destroy();
header('Location: index.php');
exit;
